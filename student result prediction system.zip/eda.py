"""
Exploratory Data Analysis (EDA) Module
=======================================
Generates visualizations and statistics to understand the dataset.

ML Concepts:
    - Descriptive Statistics
    - Correlation Analysis
    - Data Distribution Visualization
    - Class Balance Analysis
"""

import os
import matplotlib
matplotlib.use("Agg")  # Non-interactive backend for saving plots
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd


# ---------------------------------------------------------------------------
# Path configuration
# ---------------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
GRAPHS_DIR = os.path.join(BASE_DIR, "Results", "Graphs")


def ensure_graphs_dir():
    """Create the Graphs output directory if it doesn't exist."""
    os.makedirs(GRAPHS_DIR, exist_ok=True)


def plot_correlation_heatmap(df):
    """
    Generate a correlation heatmap for all numerical features.

    The heatmap shows how strongly each pair of features is related.
    Values close to +1 or -1 indicate strong correlation.

    Args:
        df: DataFrame with numerical columns.
    """
    ensure_graphs_dir()

    # Encode Result for correlation (handle both 'object' and 'str' dtypes)
    plot_df = df.copy()
    if plot_df["Result"].dtype in ("object", "str", "string"):
        plot_df["Result"] = plot_df["Result"].map({"Pass": 1, "Fail": 0})

    plt.figure(figsize=(8, 6))
    correlation_matrix = plot_df.select_dtypes(include="number").corr()

    sns.heatmap(
        correlation_matrix,
        annot=True,
        fmt=".2f",
        cmap="coolwarm",
        center=0,
        square=True,
        linewidths=0.5,
        cbar_kws={"shrink": 0.8},
    )
    plt.title("Feature Correlation Heatmap", fontsize=14, fontweight="bold", pad=15)
    plt.tight_layout()

    save_path = os.path.join(GRAPHS_DIR, "correlation_heatmap.png")
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()

    print(f"[INFO] Correlation heatmap saved -> {save_path}")
    print(f"\nCorrelation Matrix:\n{correlation_matrix}")


def plot_feature_distributions(df):
    """
    Plot histograms showing the distribution of each feature.

    Helps identify the spread, skewness, and range of each variable.

    Args:
        df: Raw DataFrame.
    """
    ensure_graphs_dir()

    features = ["Attendance", "Study_Hours", "Internal_Marks"]

    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    colors = ["#3498db", "#2ecc71", "#e74c3c"]

    for idx, (feature, color) in enumerate(zip(features, colors)):
        axes[idx].hist(df[feature], bins=15, color=color, edgecolor="white", alpha=0.8)
        axes[idx].set_title(f"{feature} Distribution", fontsize=12, fontweight="bold")
        axes[idx].set_xlabel(feature)
        axes[idx].set_ylabel("Frequency")
        axes[idx].grid(axis="y", alpha=0.3)

    plt.suptitle("Feature Distributions", fontsize=14, fontweight="bold", y=1.02)
    plt.tight_layout()

    save_path = os.path.join(GRAPHS_DIR, "feature_distributions.png")
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()

    print(f"[INFO] Feature distributions plot saved -> {save_path}")


def plot_class_balance(df):
    """
    Plot a bar chart showing the count of Pass vs Fail students.

    Helps identify if the dataset is balanced or imbalanced.

    Args:
        df: Raw DataFrame with 'Result' column.
    """
    ensure_graphs_dir()

    result_counts = df["Result"].value_counts()

    plt.figure(figsize=(6, 5))
    bars = plt.bar(
        result_counts.index,
        result_counts.values,
        color=["#2ecc71", "#e74c3c"],
        edgecolor="white",
        width=0.5,
    )

    # Add count labels on bars
    for bar, count in zip(bars, result_counts.values):
        plt.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 0.5,
            str(count),
            ha="center",
            va="bottom",
            fontsize=14,
            fontweight="bold",
        )

    plt.title("Class Balance: Pass vs Fail", fontsize=14, fontweight="bold", pad=15)
    plt.xlabel("Result")
    plt.ylabel("Count")
    plt.grid(axis="y", alpha=0.3)
    plt.tight_layout()

    save_path = os.path.join(GRAPHS_DIR, "class_balance.png")
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()

    print(f"[INFO] Class balance chart saved -> {save_path}")
    print(f"\nClass Distribution:\n{result_counts}")


def plot_boxplots(df):
    """
    Plot boxplots of each feature grouped by Result (Pass/Fail).

    Boxplots reveal the median, quartiles, and outliers for each group.

    Args:
        df: Raw DataFrame.
    """
    ensure_graphs_dir()

    features = ["Attendance", "Study_Hours", "Internal_Marks"]

    fig, axes = plt.subplots(1, 3, figsize=(15, 5))

    for idx, feature in enumerate(features):
        sns.boxplot(
            data=df, x="Result", y=feature, ax=axes[idx],
            hue="Result", palette={"Pass": "#2ecc71", "Fail": "#e74c3c"},
            legend=False,
        )
        axes[idx].set_title(f"{feature} by Result", fontsize=12, fontweight="bold")
        axes[idx].grid(axis="y", alpha=0.3)

    plt.suptitle("Feature Boxplots by Result", fontsize=14, fontweight="bold", y=1.02)
    plt.tight_layout()

    save_path = os.path.join(GRAPHS_DIR, "feature_boxplots.png")
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()

    print(f"[INFO] Feature boxplots saved -> {save_path}")


def run_eda(df):
    """
    Execute the full EDA pipeline.

    Generates all visualizations and saves them to Results/Graphs/.

    Args:
        df: Raw DataFrame (before encoding).
    """
    print("\n" + "=" * 60)
    print("STEP 2: EXPLORATORY DATA ANALYSIS (EDA)")
    print("=" * 60)

    plot_correlation_heatmap(df)
    plot_feature_distributions(df)
    plot_class_balance(df)
    plot_boxplots(df)

    print("\n[INFO] All EDA plots generated successfully!")
