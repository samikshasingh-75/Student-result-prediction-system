"""
Data Preprocessing Module
=========================
Handles loading, cleaning, encoding, and splitting the student dataset.

ML Concepts:
    - Data Loading with pandas
    - Missing Value & Duplicate Detection
    - Label Encoding (categorical -> numerical)
    - Train-Test Split (80/20)
"""

import os
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split


# ---------------------------------------------------------------------------
# Path configuration
# ---------------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATASET_PATH = os.path.join(BASE_DIR, "Dataset", "student_data.csv")


def load_data(filepath=DATASET_PATH):
    """
    Load the student dataset from CSV.

    Returns:
        pd.DataFrame: Raw dataset.
    """
    df = pd.read_csv(filepath)
    print(f"[INFO] Dataset loaded successfully — {df.shape[0]} rows, {df.shape[1]} columns")
    return df


def inspect_data(df):
    """
    Print basic dataset information for understanding the data.

    Displays:
        - First 5 rows
        - Data types and non-null counts
        - Statistical summary
        - Missing value count
        - Duplicate row count
    """
    print("\n" + "=" * 60)
    print("DATA INSPECTION")
    print("=" * 60)

    print("\n--- First 5 Rows ---")
    print(df.head())

    print("\n--- Data Types & Info ---")
    print(df.dtypes)
    print(f"\nShape: {df.shape}")

    print("\n--- Statistical Summary ---")
    print(df.describe())

    print("\n--- Missing Values ---")
    missing = df.isnull().sum()
    print(missing)
    print(f"Total missing: {missing.sum()}")

    print("\n--- Duplicate Rows ---")
    duplicates = df.duplicated().sum()
    print(f"Duplicate rows: {duplicates}")

    return {
        "shape": df.shape,
        "missing_total": int(missing.sum()),
        "duplicates": int(duplicates),
    }


def clean_data(df):
    """
    Clean the dataset by handling missing values and duplicates.

    Steps:
        1. Drop duplicate rows (if any)
        2. Drop rows with missing values (if any)

    Returns:
        pd.DataFrame: Cleaned dataset.
    """
    initial_rows = len(df)

    # Remove duplicates
    df = df.drop_duplicates()
    after_dedup = len(df)
    if initial_rows != after_dedup:
        print(f"[INFO] Removed {initial_rows - after_dedup} duplicate rows")

    # Remove rows with missing values
    df = df.dropna()
    after_dropna = len(df)
    if after_dedup != after_dropna:
        print(f"[INFO] Removed {after_dedup - after_dropna} rows with missing values")

    if initial_rows == after_dropna:
        print("[INFO] No cleaning needed — dataset is already clean")

    return df.reset_index(drop=True)


def encode_target(df, target_column="Result"):
    """
    Encode the target column from categorical (Pass/Fail) to numerical (1/0).

    Uses sklearn's LabelEncoder:
        - Pass -> 1
        - Fail -> 0

    Args:
        df: DataFrame with the target column.
        target_column: Name of the target column.

    Returns:
        tuple: (encoded DataFrame, LabelEncoder instance)
    """
    le = LabelEncoder()
    df[target_column] = le.fit_transform(df[target_column])

    # Print the encoding mapping
    mapping = dict(zip(le.classes_, le.transform(le.classes_)))
    print(f"[INFO] Label Encoding: {mapping}")

    return df, le


def split_features_target(df, target_column="Result"):
    """
    Separate features (X) and target (y).

    Args:
        df: Encoded DataFrame.
        target_column: Name of the target column.

    Returns:
        tuple: (X, y) — features DataFrame and target Series.
    """
    X = df.drop(columns=[target_column])
    y = df[target_column]

    print(f"[INFO] Features: {list(X.columns)}")
    print(f"[INFO] Target: {target_column}")
    print(f"[INFO] Feature matrix shape: {X.shape}")

    return X, y


def split_train_test(X, y, test_size=0.2, random_state=42):
    """
    Split data into training and testing sets (80/20 split).

    Args:
        X: Feature matrix.
        y: Target vector.
        test_size: Fraction of data for testing (default 0.2 = 20%).
        random_state: Seed for reproducibility.

    Returns:
        tuple: (X_train, X_test, y_train, y_test)
    """
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state
    )

    print(f"\n[INFO] Train-Test Split (test_size={test_size}):")
    print(f"       Training set: {X_train.shape[0]} samples")
    print(f"       Testing set:  {X_test.shape[0]} samples")

    return X_train, X_test, y_train, y_test


def run_preprocessing():
    """
    Execute the full preprocessing pipeline.

    Returns:
        dict: Contains X_train, X_test, y_train, y_test, label_encoder, and raw_df.
    """
    print("\n" + "=" * 60)
    print("STEP 1: DATA PREPROCESSING")
    print("=" * 60)

    # Load
    df = load_data()

    # Inspect
    inspect_data(df)

    # Clean
    df = clean_data(df)

    # Encode target
    df, label_encoder = encode_target(df)

    # Split features and target
    X, y = split_features_target(df)

    # Train-test split
    X_train, X_test, y_train, y_test = split_train_test(X, y)

    return {
        "X_train": X_train,
        "X_test": X_test,
        "y_train": y_train,
        "y_test": y_test,
        "label_encoder": label_encoder,
        "raw_df": load_data(),  # reload raw for EDA
        "feature_names": list(X.columns),
    }
