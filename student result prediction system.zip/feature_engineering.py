"""
Feature Engineering Module
===========================
Applies feature scaling to normalize the data for better model performance.

ML Concepts:
    - Feature Scaling (StandardScaler)
    - Scaler Serialization (save for reuse in predictions)
"""

import os
import joblib
from sklearn.preprocessing import StandardScaler


# ---------------------------------------------------------------------------
# Path configuration
# ---------------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODELS_DIR = os.path.join(BASE_DIR, "models")


def ensure_models_dir():
    """Create the models output directory if it doesn't exist."""
    os.makedirs(MODELS_DIR, exist_ok=True)


def scale_features(X_train, X_test):
    """
    Apply StandardScaler to normalize features.

    StandardScaler transforms each feature to have:
        - Mean = 0
        - Standard Deviation = 1

    This ensures all features contribute equally to the model,
    regardless of their original scale.

    Formula: z = (x - mean) / std

    Args:
        X_train: Training feature matrix.
        X_test: Testing feature matrix.

    Returns:
        tuple: (X_train_scaled, X_test_scaled, scaler)
    """
    scaler = StandardScaler()

    # Fit on training data only (to avoid data leakage)
    X_train_scaled = scaler.fit_transform(X_train)

    # Transform test data using the same scaler
    X_test_scaled = scaler.transform(X_test)

    print("[INFO] Feature scaling applied (StandardScaler)")
    print(f"       Training mean after scaling: {X_train_scaled.mean(axis=0).round(6)}")
    print(f"       Training std after scaling:  {X_train_scaled.std(axis=0).round(4)}")

    return X_train_scaled, X_test_scaled, scaler


def save_scaler(scaler, filename="scaler.pkl"):
    """
    Save the fitted scaler to disk for reuse during predictions.

    Args:
        scaler: Fitted StandardScaler instance.
        filename: Output filename.
    """
    ensure_models_dir()
    save_path = os.path.join(MODELS_DIR, filename)
    joblib.dump(scaler, save_path)
    print(f"[INFO] Scaler saved -> {save_path}")


def load_scaler(filename="scaler.pkl"):
    """
    Load a previously saved scaler from disk.

    Args:
        filename: Scaler filename.

    Returns:
        StandardScaler: Fitted scaler instance.
    """
    load_path = os.path.join(MODELS_DIR, filename)
    scaler = joblib.load(load_path)
    print(f"[INFO] Scaler loaded <- {load_path}")
    return scaler


def run_feature_engineering(X_train, X_test):
    """
    Execute the full feature engineering pipeline.

    Steps:
        1. Scale features using StandardScaler
        2. Save the scaler for prediction reuse

    Args:
        X_train: Training feature matrix.
        X_test: Testing feature matrix.

    Returns:
        tuple: (X_train_scaled, X_test_scaled, scaler)
    """
    print("\n" + "=" * 60)
    print("STEP 3: FEATURE ENGINEERING")
    print("=" * 60)

    X_train_scaled, X_test_scaled, scaler = scale_features(X_train, X_test)
    save_scaler(scaler)

    return X_train_scaled, X_test_scaled, scaler
