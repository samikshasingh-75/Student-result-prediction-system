"""
Model Evaluation Module
========================
Evaluates the trained model on the test set and generates metrics.

ML Concepts:
    - Accuracy Score
    - Confusion Matrix
    - Classification Report (Precision, Recall, F1-Score)
    - Confusion Matrix Visualization
"""

import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    classification_report,
)


# ---------------------------------------------------------------------------
# Path configuration
# ---------------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
GRAPHS_DIR = os.path.join(BASE_DIR, "Results", "Graphs")


def ensure_graphs_dir():
    """Create the Graphs output directory if it doesn't exist."""
    os.makedirs(GRAPHS_DIR, exist_ok=True)


def evaluate_model(model, X_test_scaled, y_test):
    """
    Evaluate the trained model on the test set.

    Computes and prints:
        - Accuracy: Overall percentage of correct predictions
        - Confusion Matrix: Shows TP, TN, FP, FN counts
        - Classification Report: Precision, Recall, F1-Score per class

    Args:
        model: Trained model.
        X_test_scaled: Scaled test feature matrix.
        y_test: True test labels.

    Returns:
        dict: Evaluation metrics.
    """
    # Make predictions on the test set
    y_pred = model.predict(X_test_scaled)

    # --- Accuracy ---
    accuracy = accuracy_score(y_test, y_pred)
    print(f"\n   Accuracy: {accuracy * 100:.2f}%")

    # --- Confusion Matrix ---
    cm = confusion_matrix(y_test, y_pred)
    print(f"\n   Confusion Matrix:")
    print(f"   {cm}")
    print(f"\n   Interpretation:")
    print(f"     True Negatives  (Fail predicted as Fail): {cm[0][0]}")
    print(f"     False Positives (Fail predicted as Pass): {cm[0][1]}")
    print(f"     False Negatives (Pass predicted as Fail): {cm[1][0]}")
    print(f"     True Positives  (Pass predicted as Pass): {cm[1][1]}")

    # --- Classification Report ---
    report = classification_report(y_test, y_pred, target_names=["Fail", "Pass"])
    print(f"\n   Classification Report:")
    print(report)

    return {
        "accuracy": accuracy,
        "confusion_matrix": cm,
        "y_pred": y_pred,
        "report": report,
    }


def plot_confusion_matrix(cm):
    """
    Visualize the confusion matrix as a heatmap.

    The confusion matrix shows how well the model distinguishes
    between Pass and Fail students.

    Args:
        cm: Confusion matrix array.
    """
    ensure_graphs_dir()

    plt.figure(figsize=(6, 5))
    sns.heatmap(
        cm,
        annot=True,
        fmt="d",
        cmap="Blues",
        xticklabels=["Fail", "Pass"],
        yticklabels=["Fail", "Pass"],
        linewidths=1,
        linecolor="white",
        cbar_kws={"shrink": 0.8},
    )
    plt.title("Confusion Matrix", fontsize=14, fontweight="bold", pad=15)
    plt.xlabel("Predicted Label", fontsize=12)
    plt.ylabel("True Label", fontsize=12)
    plt.tight_layout()

    save_path = os.path.join(GRAPHS_DIR, "confusion_matrix.png")
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()

    print(f"[INFO] Confusion matrix plot saved -> {save_path}")


def run_evaluation(model, X_test_scaled, y_test):
    """
    Execute the full evaluation pipeline.

    Steps:
        1. Compute accuracy, confusion matrix, classification report
        2. Save confusion matrix plot

    Args:
        model: Trained model.
        X_test_scaled: Scaled test features.
        y_test: True test labels.

    Returns:
        dict: Evaluation metrics.
    """
    print("\n" + "=" * 60)
    print("STEP 5: MODEL EVALUATION")
    print("=" * 60)

    metrics = evaluate_model(model, X_test_scaled, y_test)
    plot_confusion_matrix(metrics["confusion_matrix"])

    print("\n[INFO] Model evaluation complete!")

    return metrics
