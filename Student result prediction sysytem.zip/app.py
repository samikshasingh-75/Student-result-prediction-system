from predict import predict_result

def main():
    print("=" * 50)
    print("STUDENT RESULT PREDICTION SYSTEM")
    print("=" * 50)

    try:
        attendance = float(input("Enter Attendance (%): "))
        study_hours = float(input("Enter Study Hours Per Day: "))
        internal_marks = float(input("Enter Internal Marks: "))

        result = predict_result(
            attendance,
            study_hours,
            internal_marks
        )

        print("\nPrediction Result")
        print("-" * 30)
        print(f"Result: {result['result']}")
        print(f"Confidence: {result['probability']}%")
        print(f"Pass Probability: {result['pass_probability']}%")
        print(f"Fail Probability: {result['fail_probability']}%")

    except ValueError:
        print("Please enter valid numeric values.")

if __name__ == "__main__":
    main()