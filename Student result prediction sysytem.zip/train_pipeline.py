"""
Complete Training Pipeline
==========================
Runs the entire ML pipeline from data preprocessing to model training.
"""

from data_preprocessing import load_data, inspect_data, clean_data, encode_target, split_features_target, split_train_test
from feature_engineering import run_feature_engineering
from model_training import run_model_training
from model_evaluation import run_evaluation

print("\n" + "=" * 60)
print("STUDENT RESULT PREDICTION SYSTEM - TRAINING PIPELINE")
print("=" * 60)

# Step 1: Data Preprocessing
print("\n" + "=" * 60)
print("STEP 1: DATA PREPROCESSING")
print("=" * 60)

df = load_data()
inspect_data(df)
df = clean_data(df)
df, _ = encode_target(df)
X, y = split_features_target(df)
X_train, X_test, y_train, y_test = split_train_test(X, y)

# Step 2: Feature Engineering
X_train_scaled, X_test_scaled, scaler = run_feature_engineering(X_train, X_test)

# Step 3: Model Training
model = run_model_training(X_train_scaled, y_train)

# Step 4: Model Evaluation
run_evaluation(model, X_test_scaled, y_test)

print("\n" + "=" * 60)
print("✓ TRAINING COMPLETE - Model and Scaler Saved")
print("=" * 60 + "\n")
