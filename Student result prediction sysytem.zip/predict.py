"""
Prediction Module
==================
Loads the saved model and scaler to make predictions on new student data.

ML Concepts:
    - Model Loading (deserialization)
    - Feature Scaling on new data
    - Probability Prediction
"""

import os
import numpy as np
import joblib


# ---------------------------------------------------------------------------
# Path configuration
# ---------------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODELS_DIR = os.path.join(BASE_DIR, "models")


def load_model_and_scaler():
    """
    Load the trained model and fitted scaler from disk.

    Returns:
        tuple: (model, scaler)
    """
    model_path = os.path.join(MODELS_DIR, "logistic_regression_model.pkl")
    scaler_path = os.path.join(MODELS_DIR, "scaler.pkl")

    model = joblib.load(model_path)
    scaler = joblib.load(scaler_path)

    return model, scaler


def predict_result(attendance, study_hours, internal_marks):
    """
    Predict whether a student will Pass or Fail.

    Pipeline:
        1. Load saved model and scaler
        2. Create feature array from input
        3. Scale features using the saved scaler
        4. Predict class and probability

    Args:
        attendance (float): Student's attendance percentage (0-100).
        study_hours (float): Daily study hours.
        internal_marks (float): Internal exam marks.

    Returns:
        dict: {
            "result": "Pass" or "Fail",
            "probability": float (confidence percentage),
            "pass_probability": float,
            "fail_probability": float,
        }
    """
    # Load model and scaler
    model, scaler = load_model_and_scaler()

    # Create input feature array
    input_features = np.array([[attendance, study_hours, internal_marks]])

    # Scale the input using the same scaler used during training
    input_scaled = scaler.transform(input_features)

    # Predict class (0 = Fail, 1 = Pass)
    prediction = model.predict(input_scaled)[0]

    # Get prediction probabilities
    probabilities = model.predict_proba(input_scaled)[0]
    fail_prob = probabilities[0] * 100
    pass_prob = probabilities[1] * 100

    # Map prediction to label
    result = "Pass" if prediction == 1 else "Fail"
    confidence = pass_prob if prediction == 1 else fail_prob

    return {
        "result": result,
        "probability": round(confidence, 2),
        "pass_probability": round(pass_prob, 2),
        "fail_probability": round(fail_prob, 2),
    }
