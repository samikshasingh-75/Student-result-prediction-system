

"""
Model Training Module
======================
Trains a Logistic Regression model and saves it for future predictions.

ML Concepts:
    - Logistic Regression (binary classification)
    - Model Fitting (learning from training data)
    - Model Serialization (saving with joblib)
"""

import os
import joblib
from sklearn.linear_model import LogisticRegression


# ---------------------------------------------------------------------------
# Path configuration
# ---------------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODELS_DIR = os.path.join(BASE_DIR, "models")


def ensure_models_dir():
    """Create the models output directory if it doesn't exist."""
    os.makedirs(MODELS_DIR, exist_ok=True)


def train_logistic_regression(X_train, y_train):
    """
    Train a Logistic Regression model.

    Logistic Regression is a linear model for binary classification.
    It predicts the probability that an input belongs to a particular class
    using the sigmoid function: P(y=1|x) = 1 / (1 + e^(-z))

    Args:
        X_train: Scaled training feature matrix.
        y_train: Training target vector (0 or 1).

    Returns:
        LogisticRegression: Trained model instance.
    """
    model = LogisticRegression(
        random_state=42,
        max_iter=1000,
    )

    model.fit(X_train, y_train)

    print("[INFO] Logistic Regression model trained successfully")
    print(f"       Coefficients: {model.coef_[0].round(4)}")
    print(f"       Intercept:    {model.intercept_[0]:.4f}")
    print(f"       Training Accuracy: {model.score(X_train, y_train) * 100:.2f}%")

    return model


def save_model(model, filename="logistic_regression_model.pkl"):
    """
    Save the trained model to disk using joblib.

    Args:
        model: Trained model instance.
        filename: Output filename.
    """
    ensure_models_dir()
    save_path = os.path.join(MODELS_DIR, filename)
    joblib.dump(model, save_path)
    print(f"[INFO] Model saved -> {save_path}")


def load_model(filename="logistic_regression_model.pkl"):
    """
    Load a previously saved model from disk.

    Args:
        filename: Model filename.

    Returns:
        Trained model instance.
    """
    load_path = os.path.join(MODELS_DIR, filename)
    model = joblib.load(load_path)
    print(f"[INFO] Model loaded <- {load_path}")
    return model


def run_model_training(X_train_scaled, y_train):
    """
    Execute the full model training pipeline.

    Steps:
        1. Train Logistic Regression model
        2. Save the trained model to disk

    Args:
        X_train_scaled: Scaled training feature matrix.
        y_train: Training target vector.

    Returns:
        Trained LogisticRegression model.
    """
    print("\n" + "=" * 60)
    print("STEP 4: MODEL TRAINING")
    print("=" * 60)

    model = train_logistic_regression(X_train_scaled, y_train)
    save_model(model)

    return model
